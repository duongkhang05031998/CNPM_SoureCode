<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
</head>
<body>
<div>
	@foreach($banchay as $bc)
	{{$bc->content}}
	@endforeach
</div>
</body>
</html>
