<div  id="footer">
         <div class="container">
          <div class="row">
            <div class="col-sm-4 s-left">
              <footer>
        <a href="index.php"><img src="public\image\icon\4.jpg" width="260px" height="70px" style="border: 1px solid black; margin-top: 20px; "></a>
        <p  style="color: white; margin-top: 10px">ĐỊA CHỈ: 123 LONG XUYÊN - AN GIANG</p>
       
      </footer>
            </div>
            <div class="col-sm-4" id="trogiup">
              <p style=" margin-top: 20px; "><a href="gioithieu.html" target="_blank" style="color: white">Giới thiệu</a><p>
              <p ><a href="trogiup.html" target="_blank" style="color: white">Trợ giúp</a><p>
              <p >Liên hệ: 012345678<p>
                 {{-- @if(Auth::check())
                  <p><a href="{{ route('homeadmin') }}" style="color: white">Quản trị</a></p>
                 @else
                  <p><a href="{{ route('loginquantri') }}" style="color: white">Quản trị</a></p>
                  @endif --}}
            </div>
            <div class="col-sm-4">
              <img src="public\image\icon\fb.png" width="25px" height="25px" style="float: left;margin-top: 20px">
              <a href="https://www.facebook.com/profile.php?id=100038868171107" target="_blank" style="color: white"><p style="margin-top: 20px; margin-left: 10px">FaceBook</p></a>
              <br style="clear: left;">
              
			  <img src="public\image\icon\zalo.jpg" width="15px" height="15px" style="float: left; margin-top: -20px;margin-left: 4px">
			  <a href="https://id.zalo.me/account/login?continue=https%3A%2F%2Fchat.zalo.me%2F" target="_blank" style="color: white"><p style="margin-left: 27px;margin-top: -24px">Zalo</p></a>
			  <br style="clear: left;">
			  
				<img src="public\image\icon\youtobe.png" width="15px" height="15px" style="float: left; margin-top: -18px; margin-left: 5px">
			  <a href="https://www.youtube.com/watch?v=dLQe4qEfVJw" target="_blank" style="color: white"><p style="margin-left: 27px; margin-top: -24px">Youtube</p></a>	
          
            </div>
          </div>
          
         </div>
      </div>