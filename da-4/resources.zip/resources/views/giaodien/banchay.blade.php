@extends('giaodien.master')
@section('title','Thương Hiệu  ')
@section('content')

<div>
 
</div>

@endsection