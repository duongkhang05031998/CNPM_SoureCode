<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.6/umd/popper.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.2.1/js/bootstrap.min.js"></script>
	<title>Giao diện</title>

</head>
<body>
<div style="width:100%; height: 50px; background-color: black ">
	<img src="a.png" width="15px" height="15px" style="margin-left: 80px; margin-top: 15px; float: left;margin-right: 10px">
	<a style=" color: white; font-size: 13px; margin-left: 10px;float: left;margin-top: 13px" href="" >Hotline : 0367.893.306</a>
	<form>
		<input class="form-control" style="width: 300px; height: 30px; float: left;font-size: 12; margin-left: 650px; margin-top: 5px " type="text" placeholder="từ khóa tìm kiếm">
             <button type="submit" class="btn" name="ok" style="float: left;border: 0;margin-left: -45px;float: left;"><img src="public\image\producer\timkiem.png" width="25" height="24"></button>
             <img src="public\image\icon\b.png" width="25px" height="25px" style="margin-top: 7px; margin-left: 40px">
	</form>

</div>
<div>
	<nav class="navbar navbar-expand-sm  navbar-dark">
  

  <!-- Links -->
  <ul class="navbar-nav">
   <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle " href="#" id="navbardrop" data-toggle="dropdown" style="color: black; margin-left: 57px">
        THƯƠNG HIỆU
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="#">Link 1</a>
        <a class="dropdown-item" href="#">Link 2</a>
        <a class="dropdown-item" href="#">Link 3</a>
      </div>
    </li>
    <li class="nav-item">
      <a class="nav-link"  style="color: black" href="#">NAM</a>
    </li>
    <li class="nav-item">
      <a class="nav-link"  style="color: black" href="#">NỮ</a>
    </li>
    <li class="nav-item">
      <a class="nav-link"  style="color: black" href="#">ĐÔI</a>
    </li>
    <li class="nav-item">
      <a class="nav-link"  style="color: orange; margin-left:200px; font-size: 25px; font-weight: bold; font-family:cursive; " href="#">SHOP ĐỒNG HỒ</a>
    </li>
     <li class="nav-item">
      <a class="nav-link"  style="color: black; margin-left: 200px" href="#">TOP 100</a>
    </li>
    <li class="nav-item dropdown">
      <a class="nav-link dropdown-toggle " href="#" id="navbardrop" data-toggle="dropdown" style="color: black;">
        TREO TƯỜNG
      </a>
      <div class="dropdown-menu">
        <a class="dropdown-item" href="#">Link 1</a>
        <a class="dropdown-item" href="#">Link 2</a>
        <a class="dropdown-item" href="#">Link 3</a>
      </div>
    </li>
   <li class="nav-item">
      <a class="nav-link"  style="color: black;" href="#">LIÊN HỆ</a>
    </li>
   
  </ul>
</nav>
</div>
<div id="myCarousel" class="carousel slide" data-ride="carousel" s>
    
    <ul class="carousel-indicators">
       <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
       <li data-target="#myCarousel" data-slide-to="1"></li>
       <li data-target="#myCarousel" data-slide-to="2"></li>
    </ul>
   <div class="carousel-inner">
    <div class="carousel-item active">
      <a href=""><img src="public\image\slide1\e.jpg" alt="Los Angeles" width="100%" height="400px"></a>
    </div>
    <div class="carousel-item">
     <a href=""> <img src="public\image\slide1\c.jpg" alt="Chicago"  width="100%" height="400px" ></a>
    </div>
    <div class="carousel-item">
     <a href=""> <img src="public\image\slide1\d.jpg" alt="New York"   width="100%" height="400px"></a>
    </div>
  </div>
  <a class="carousel-control-prev" href="#myCarousel" data-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </a>
  <a class="carousel-control-next" href="#myCarousel" data-slide="next">
    <span class="carousel-control-next-icon"></span>
  </a>
  </div>
  <div  style="text-align: center;">
    <h3 style="margin-top: 30px; ">ĐỒNG HỒ CHÍNH HÃNG CAO CẤP</h3>
    <p style="color: grey">Chúng tôi cam kết mang lại những giá trị cao nhất, chế độ hậu mãi tốt nhất & đồng </p>
    <p style="margin-top: -13px;color: grey">hồ chính hãng cho khách hàng khi đến với SHOPDONGHO.com</p>
  </div>
  <div class="row">
    <div class="col-lg-2">
      <img src="public\image\slide2\baohanh.jpg" width="100" height="100" style="margin-left: 50px">
      <p style="font-size: 12px; text-align: center;">BẢO HÀNH MÁY VÀ PIN 5 NĂM</p>
    </div>
    <div class="col-lg-2">
      <img src="public\image\slide2\giamgia.png" width="100" height="100" style="margin-left: 50px">
      <p style="font-size: 12px; text-align: center;">GIẢM GIÁ 10% GIÁ CHÍNH HÃNG</p>
    </div>
    <div class="col-lg-2">
      <img src="public\image\slide2\cod.jpg" width="100" height="100" style="margin-left: 50px">
      <p style="font-size: 12px; text-align: center;">CHUYỂN HÀNG COD MIỄN PHÍ TOÀN QUỐC</p>
    </div>
    <div class="col-lg-2">
      <img src="public\image\slide2\1v1.png" width="100" height="100" style="margin-left: 50px">
      <p style="font-size: 12px; text-align: center;">CHẾ ĐỘ 1 ĐỔI 1 TRONG 7 NGÀY ĐẦU</p>
    </div>
    <div class="col-lg-2">
      <img src="public\image\slide2\qua.png" width="100" height="100" style="margin-left: 50px">
      <p style="font-size: 12px; text-align: center;">TẶNG KHĂN LAU ĐỒNG HỒ CAO CẤP</p>
    </div>
    <div class="col-lg-2">
      <img src="public\image\slide2\giamgia.png" width="100" height="100" style="margin-left: 50px">
      <p style="font-size: 12px; text-align: center;">THAY GIÂY DA GIẢM GIÁ 50%</p>
    </div>
  </div>
  <div>
    <h2 style="text-align: center;margin-top: 30px; color: orange; font-family: cursive;">ĐỒNG HỒ BÁN CHẠY NHẤT</h2>
  </div>
  <div class="row">
    <div class="col-lg-3">
       <img src="public/1.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ Casio AE-1200WHD-1AVDF nam pin dây inox</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">1.246.000 đ</strike>1.121.000 đ</p>
    </div>
    <div class="col-lg-3">
       <img src="2.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ Casio B640WC-5ADF pin nam inox</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">1.739.000 đ</strike>1.565.000 đ</p>
    </div>
    <div class="col-lg-3">
       <img src="3.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ casio MTP-1374L-1AVDF nam pin dây da</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">1.940.000 đ</strike>1.714.000 đ</p>
    </div>
    <div class="col-lg-3">
       <img src="4.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ Daniel Wellington DW00100163 Nữ Pin Dây Inox</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">4.000.000 đ</strike>3.600.000 đ</p>
    </div>
  </div>


  <div class="row">
    <div class="col-lg-3">
       <img src="5.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ Daniel Wellington DW00100161 Nữ Pin Dây Inox</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">4.000.000 đ</strike>3.600.000 đ</p>
    </div>
    <div class="col-lg-3">
       <img src="6.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ Daniel Wellington DW00100217 Nữ Pin Dây Inox</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">3.600.000 đ</strike>3.240.000 đ</p>
    </div>
    <div class="col-lg-3">
       <img src="7.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ Daniel Wellington DW00100219 Nữ Pin Dây Inox</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">3.600.000 đ</strike>3.240.000 đ</p>
    </div>
    <div class="col-lg-3">
       <img src="8.jpg" width="250" height="300" style="margin-left: 80px">
      <p style="font-size: 14px; text-align: center; margin-left: 100px">Đồng hồ casio DW-5600E-1VDF nam pin dây nhựa</p>
      <p style="font-size: 15px; text-align: center; margin-left: 100px; color: orange"><strike style="color: grey; margin-right: 10px">1.904.000 đ</strike>1.714.000 đ</p>
    </div>
  </div>
  <div>
    <button style="margin-top: 30px; margin-left: 640px; margin-bottom: 30px">XEM THÊM</button>
  </div>

  <div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-5" style="height: 250px; background-image: url(public\image\slide3\dhn.jpg);margin-right: 20px" >
      <p style="color: white; font-size: 22px; margin-top: 25px"> ĐỒNG HỒ NAM</p>
    </div>
    <div class="col-lg-5" style="height: 250px; background-image: url(public\image\slide3\dhnu.jpg);" >
      <p style=" font-size: 22px; margin-top: 25px"> ĐỒNG HỒ NỮ</p>
    </div>
  </div>
  <br>
  <div class="row">
    <div class="col-lg-1"></div>
    <div class="col-lg-2" style="height: 200px; background-image: url(public\image\slide3\hot.jpg);margin-right: 83px;" >
      <p style="color: white; font-size: 15px; margin-top: 25px; text-align: center;"> ĐỒNG HỒ HOT</p>
    </div>
     <div class="col-lg-2" style="height: 200px; background-image: url(public\image\slide3\pin.jpg);margin-right: 83px" >
      <p style="color: white; font-size: 15px; margin-top: 25px; text-align: center;"> ĐỒNG HỒ PIN</p>
    </div>
     <div class="col-lg-2" style="height: 200px; background-image: url(public\image\slide3\co.jpg);margin-right: 83px" >
      <p style="color: white; font-size: 15px; margin-top: 25px; text-align: center;"> ĐỒNG HỒ CƠ</p>
    </div>
     <div class="col-lg-2" style="height: 200px; background-image: url(public\image\slide3\doi.jpg);margin-right: 85px" >
      <p style="color: white; font-size: 15px; margin-top: 25px; text-align: center;"> ĐỒNG HỒ ĐÔI</p>
    </div>
  </div>

  <div>
    <h3 style="text-align: center; margin-top: 30px; font-family: cursive; margin-bottom: 30px">THƯƠNG HIỆU ĐỒNG HỒ</h3>
  </div>
  <div>
    <img src="public\image\producer\11.png" width="166" height="100" style="margin-left: 100px; margin-right: 30px">
    <img src="public\image\producer\12.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\13.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\14.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\15.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\16.png" width="166" height="100" style=" margin-right: 25px">
  </div>
  <div style="margin-top: 30px">
    <img src="public\image\producer\17.png" width="166" height="100" style="margin-left: 100px; margin-right: 30px">
    <img src="public\image\producer\18.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\19.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\dong-ho-fossil.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\21.png" width="166" height="100" style=" margin-right: 30px">
    <img src="public\image\producer\22.png" width="166" height="100" style=" margin-right: 25px">
  </div>
  <br>
  <br>
  <br>
  <div  id="footer" style="background-color: black; width:100%; height: 140">
         <div class="container">
          <div class="row">
            <div class="col-sm-4 s-left">
              <footer>
        <a href="index.php"><img src="logo.png" width="75px" height="50px" style="border: 1px solid black; margin-top: 20px; margin-left: 20px"></a>
        <p style="color: white; margin-top: 10px">ĐỊA CHỈ: LONG XUYÊN - AN GIANG</p>
            
      </footer>
            </div>
            <div class="col-sm-4">
              <p  style="text-align: left; margin-left: 20px; margin-top: 20px; "><a href="gioithieu.html" target="_blank" style="color: white;">Giới thiệu</a><p>
              <p  style="text-align: left; margin-left: 20px; "><a href="trogiup.html" target="_blank" style="color: white;">Trợ giúp</a><p>
              <p  style="text-align: left; margin-left: 20px; color: white;">Liên hệ: 01667893306<p>
            </div>
            <div class="col-sm-4">
              <img src=" DoAn3_TK14.1_NguyenHoaiNam_10116048\da3\fb.png" width="25px" height="25px" style="float: left;margin-top: 20px">
              <a href="https://www.facebook.com/profile.php?id=100011659891397" target="_blank" style="color: white"><p style="margin-top: 20px; margin-left: 10px">FaceBook</p></a>
              <br style="clear: left;">
              
          <img src="DoAn3_TK14.1_NguyenHoaiNam_10116048\da3\zalo.jpg" width="15px" height="15px" style="float: left; margin-top: -20px;margin-left: 4px">
          <a href="https://id.zalo.me/account/login?continue=https%3A%2F%2Fchat.zalo.me%2F" target="_blank" style="color: white"><p style="margin-left: 27px;margin-top: -24px">Zalo</p></a>
          <br style="clear: left;">
          <img src="DoAn3_TK14.1_NguyenHoaiNam_10116048\da3\youtobe.png" width="15px" height="15px" style="float: left; margin-top: -18px; margin-left: 5px">
          <a href="https://www.youtube.com/channel/UClyA28-01x4z60eWQ2kiNbA" target="_blank" style="color: white"><p style="margin-left: 27px; margin-top: -24px">Youtobe</p></a>
          
            </div>
          </div>
          
         </div>
      </div>
    
</body>
</html>